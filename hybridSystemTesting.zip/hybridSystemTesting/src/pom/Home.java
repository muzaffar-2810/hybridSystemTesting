package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generic.Verification;

public class Home extends Verification {

	public Home(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[text()='Login']")
	private WebElement loginLink;
	
	@FindBy(xpath="//input[@name='name']")
	private WebElement usernameTF;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement passwordTF;
	
	@FindBy(xpath="//button[text()='Sign In']")
	private WebElement signinButton;
	
	@FindBy(xpath="//a[text()='Add New Employee']")
	private WebElement addNewEmployeeLink;
	
	@FindBy(xpath="//input[@id='name']")
	private WebElement nameTF;
	
	@FindBy(xpath="//input[@id='email']")
	private WebElement emailTF;
	
	@FindBy(xpath="//input[@id='phone']")
	private WebElement phoneTF;
	
	@FindBy(xpath="//input[@id='address']")
	private WebElement addressTF;
	
	@FindBy(xpath="//button[text()='Add Employee']")
	private WebElement addEmployeeButton;
	
	@FindBy(xpath="//tr//td[text()='vaish']")
	private WebElement lastname;
	
	public void clickOnLoginLink() {
		loginLink.click();
	}
	
	public void enterUserName(String userName) {
		usernameTF.sendKeys(userName);
	}
	
	public void enterPassword(String password) {
		passwordTF.sendKeys(password);
	}
	
	public void clickSignInButton() {
		signinButton.click();
	}
	
	public void clickOnAddNewEmployeeLink() {
		addNewEmployeeLink.click();
	}
	
	public void enterName(String name) {
		nameTF.sendKeys(name);
	}
	
	public void enterEmail(String email) {
		emailTF.sendKeys(email);
	}
	
	public void enterPhone(String phone) {
		phoneTF.sendKeys(phone);
	}
	
	public void enterAddress(String address) {
		addressTF.sendKeys(address);
	}
	
	public void clickAddEmployeeButton() {
		addEmployeeButton.click();
	}
	
	public void verifyLastName() {
		if(lastname.getText().equals("vaish")) {
			System.out.println("Employee has been added");
		}
	}
	
}
