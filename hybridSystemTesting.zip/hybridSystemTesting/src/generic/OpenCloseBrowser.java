package generic;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public abstract class OpenCloseBrowser implements Constants{

	public WebDriver driver;
	@BeforeMethod
	public void openBrowser(){
		driver = new ChromeDriver();
		driver.get(urloftheapplication);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterMethod
	public void closeMethod() {
		driver.manage().window().minimize();
		driver.quit();
	}
	
}
