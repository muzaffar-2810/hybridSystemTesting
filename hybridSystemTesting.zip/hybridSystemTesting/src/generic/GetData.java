package generic;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class GetData implements Constants {

	public static String getData(String sheetname, int rownumber, int cellnumber) {
		String v = "";
		try {
			FileInputStream fis = new FileInputStream(addressofexcelsheet);
			Workbook wb = WorkbookFactory.create(fis);
			v = wb.getSheet(sheetname).getRow(rownumber).getCell(cellnumber).getStringCellValue();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return v;
		
	}
}
