package generic;

public interface Constants {

	String urloftheapplication = "http://127.0.0.1:5000";
	String addressofexcelsheet = "C:\\Users\\Muzaffar Ahmed\\Desktop\\Eclipse2\\hybridSystemTesting\\driverexecutalbes\\mydata.xlsx";
}
