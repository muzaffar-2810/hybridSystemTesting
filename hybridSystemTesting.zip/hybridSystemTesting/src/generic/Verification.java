package generic;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class Verification {
	
	public WebDriver driver;
	
	public Verification(WebDriver driver){
		this.driver=driver;
	}
	
	public void verifyTitle(String expectedTitle) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			wait.until(ExpectedConditions.titleIs(expectedTitle));
			Reporter.log("Title matched", true);
		} catch(Exception e) {
			TakesScreenshot ts = (TakesScreenshot)driver;
			File tempFile = ts.getScreenshotAs(OutputType.FILE);
			String timestamp = LocalDateTime.now().toString().replace(':', '-');
			File destFile = new File("C:\\Users\\Muzaffar Ahmed\\Desktop\\Eclipse2\\hybrid4\\Screenshots\\errorshots"+timestamp+".jpeg");
			FileUtils.copyFile(tempFile, destFile);
		}
	}
	public void verifyUrl(String expectedUrl) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			wait.until(ExpectedConditions.urlToBe(expectedUrl));
			Reporter.log("Url matched",true);
		} catch (Exception e) {
			TakesScreenshot ts = (TakesScreenshot)driver;
			File tempFile = ts.getScreenshotAs(OutputType.FILE);
			String timestamp = LocalDateTime.now().toString().replace(':', '-');
			File destFile = new File("C:\\Users\\Muzaffar Ahmed\\Desktop\\Eclipse2\\hybrid4\\Screenshots\\errorshots"+timestamp+".jpeg");
			FileUtils.copyFile(tempFile, destFile);
		}
	}
}
