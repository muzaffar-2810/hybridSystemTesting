package scripts;

import org.testng.annotations.Test;

import generic.GetData;
import generic.OpenCloseBrowser;
import pom.Home;

public class AddEmployee extends OpenCloseBrowser{

	@Test
	public void addEmployee() {
		Home home = new Home(driver);
		home.clickOnLoginLink();
		String username = GetData.getData("Sheet1",6,0);
		home.enterUserName(username);
		String password = GetData.getData("Sheet1", 6, 1);
		home.enterPassword(password);
		home.clickSignInButton();
		home.clickOnAddNewEmployeeLink();
		String name = GetData.getData("Sheet1", 7, 0);
		home.enterName(name);
		String email = GetData.getData("Sheet1", 7, 1);
		home.enterEmail(email);
		String phone = GetData.getData("Sheet1", 7, 2);
		home.enterPhone(phone);
		String address = GetData.getData("Sheet1", 7, 3);
		home.enterAddress(address);
		home.clickAddEmployeeButton();
		home.verifyLastName();
	}
}
